package com.demo.repository;

import com.demo.model.CollegeStudent; 
import org.springframework.data.jpa.repository.JpaRepository;

public interface CollegeStudentRepository extends JpaRepository<CollegeStudent, Long>{

}
