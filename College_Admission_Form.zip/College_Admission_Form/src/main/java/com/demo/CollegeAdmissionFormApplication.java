package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeAdmissionFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeAdmissionFormApplication.class, args);
	}

}
