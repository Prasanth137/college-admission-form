package com.demo.controller;

import com.demo.model.CollegeStudent; 
import com.demo.service.CollegeStudentService; 
import java.util.List; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Controller; 
import org.springframework.ui.Model; 
import org.springframework.web.bind.annotation.*; 

@Controller
@RequestMapping("/collegeStudents")
public class CollegeStudentController {
	 

       @Autowired private CollegeStudentService collegeStudentService; 

		@GetMapping public String listCollegeStudents(Model model) 
		{ 
			List<CollegeStudent> collegeStudents 
				= collegeStudentService.getAllStudents(); 
			model.addAttribute("collegeStudents", collegeStudents); 
			return "collegeStudent/list"; // This should match with the actual template path 
		} 

		@GetMapping("/add") 
		public String showAddForm(Model model) 
		{ 
			model.addAttribute("collegeStudent", new CollegeStudent()); 
			return "collegeStudent/add"; 
		} 

		@PostMapping("/add") 
		public String 
		addCollegeStudent(@ModelAttribute("collegeStudent") CollegeStudent collegeStudent) 
		{ 
			collegeStudentService.saveStudent(collegeStudent); 
			return "redirect:/collegeStudents"; 
		} 

		@GetMapping("/edit/{id}") 
		public String showEditForm(@PathVariable Long id, 
								Model model) 
		{ 
			CollegeStudent collegeStudent = collegeStudentService.getStudentById(id); 
			model.addAttribute("collegeStudent", collegeStudent); 
			return "collegeStudent/edit"; 
		} 

		@PostMapping("/edit/{id}") 
		public String 
		editCollegeStudent(@PathVariable Long id, 
					@ModelAttribute("collegeStudent") CollegeStudent collegeStudent) 
		{ 
			collegeStudentService.saveStudent(collegeStudent); 
			return "redirect:/collegeStudents"; 
		} 

		@GetMapping("/delete/{id}") 
		public String deleteCollegeStudent(@PathVariable Long id) 
		{ 
			collegeStudentService.deleteStudent(id); 
			return "redirect:/collegeStudents"; 
		} 
	

}
