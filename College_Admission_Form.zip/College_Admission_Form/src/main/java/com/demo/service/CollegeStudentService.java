package com.demo.service;

import java.util.List;

import com.demo.model.CollegeStudent;

public interface CollegeStudentService {
	List<CollegeStudent> getAllStudents(); 
	  
    CollegeStudent getStudentById(Long id); 
  
    void saveStudent(CollegeStudent student); 
  
    void deleteStudent(Long id);
}
