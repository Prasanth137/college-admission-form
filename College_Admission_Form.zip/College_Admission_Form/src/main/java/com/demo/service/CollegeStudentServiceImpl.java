package com.demo.service;

import com.demo.model.CollegeStudent; 
import com.demo.repository.CollegeStudentRepository; 
import java.util.List; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service; 

@Service
public class CollegeStudentServiceImpl implements CollegeStudentService{
	
	

	
		@Autowired private CollegeStudentRepository collegeStudentRepository; 

		@Override public List<CollegeStudent> getAllStudents() 
		{ 
			return collegeStudentRepository.findAll(); 
		} 

		@Override public CollegeStudent getStudentById(Long id) 
		{ 
			return collegeStudentRepository.findById(id).orElse(null); 
		} 

		@Override public void saveStudent(CollegeStudent student) 
		{ 
			collegeStudentRepository.save(student); 
		} 

		@Override public void deleteStudent(Long id) 
		{ 
			collegeStudentRepository.deleteById(id); 
		} 
	

}
